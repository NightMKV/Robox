export interface HistoryEvent {
  year: number;
  date?: string;
  title: string;
  description: string;
  tags?: string[];
  icon?: string;
}

export interface Era {
  id: string;
  name: string;
  years: string;
  color: string;
  description: string;
  events: HistoryEvent[];
}

export const robloxEras: Era[] = [
  {
    id: "precreation",
    name: "Antes del Nacimiento",
    years: "1989 – 2003",
    color: "#6b3fa0",
    description: "Los orígenes de las mentes que crearían Roblox, y los primeros pasos del proyecto.",
    events: [
      {
        year: 1989,
        title: "Fundación de Knowledge Revolution",
        description: "David Baszucki funda Knowledge Revolution, una empresa especializada en software educativo de física y simulación mecánica. Allí desarrolla 'Interactive Physics', un simulador de física de propósito general que más tarde inspiraría a Roblox.",
        tags: ["Fundación", "Pre-Roblox"],
        icon: "🏢"
      },
      {
        year: 1997,
        title: "Erik Cassel se une a Knowledge Revolution",
        description: "Erik Cassel se une al equipo de Baszucki en Knowledge Revolution. Esta alianza sería fundamental para el futuro de Roblox.",
        tags: ["Equipo", "Pre-Roblox"],
        icon: "🤝"
      },
      {
        year: 1999,
        date: "Enero de 1999",
        title: "MSC Software adquiere Knowledge Revolution",
        description: "Knowledge Revolution es adquirida por MSC Software Corporation por 20 millones de dólares. Baszucki se convierte en vicepresidente de MSC Software, pero la venta planta la semilla para que ambos fundadores eventualmente abandonen la empresa y funden algo propio.",
        tags: ["Adquisición", "Pre-Roblox"],
        icon: "💼"
      },
      {
        year: 2000,
        title: "El sonido 'OOF' nace en otro videojuego",
        description: "El icónico sonido 'OOF' de Roblox fue creado originalmente por Tommy Tallarico para el videojuego 'Messiah' (2000). Años después este sonido sería incorporado a Roblox y se convertiría en un fenómeno cultural de internet.",
        tags: ["Dato Curioso", "Sonido"],
        icon: "🔊"
      },
      {
        year: 2003,
        date: "Diciembre de 2003",
        title: "Primeros nombres del proyecto: GoBlocks y DynaBlocks",
        description: "Baszucki y Cassel comienzan el desarrollo de lo que sería Roblox. El proyecto primero toma el nombre de 'GoBlocks.com' (2 de diciembre) y luego 'DynaBlocks.com' (12 de diciembre). También se considera brevemente el nombre 'Roblox v.10'.",
        tags: ["Desarrollo", "Nombre"],
        icon: "🧱"
      }
    ]
  },
  {
    id: "creation",
    name: "Nacimiento de Roblox",
    years: "2004 – 2005",
    color: "#e2231a",
    description: "La fundación oficial de Roblox Corporation y los primeros pasos de la plataforma.",
    events: [
      {
        year: 2004,
        date: "4 de febrero de 2004",
        title: "Registro de Roblocks.com",
        description: "El dominio 'Roblocks.com' es registrado como redirección, uno de los primeros pasos para establecer la identidad del proyecto.",
        tags: ["Dominio", "Fundación"],
        icon: "🌐"
      },
      {
        year: 2004,
        date: "23 de marzo de 2004",
        title: "Fundación oficial de Roblox Corporation",
        description: "David Baszucki y Erik Cassel fundan oficialmente Roblox Corporation. Ese mismo mes se presenta una solicitud de marca registrada para el nombre 'ROBLOX'. El nombre 'Roblox' es una combinación de 'robots' y 'blocks' (bloques).",
        tags: ["Fundación", "Histórico"],
        icon: "🎂"
      },
      {
        year: 2004,
        date: "Julio de 2004",
        title: "Primeros usuarios y playtesters",
        description: "El hilo de foro más antiguo conocido ('Couldn't install on laptop from home') es creado por David.Baszucki el 12 de julio. El 13 de julio, Todd se convierte en el primer usuario no-admin. El 23 de julio, Matt se convierte en el primer usuario menor de 13 años.",
        tags: ["Usuarios", "Beta"],
        icon: "👤"
      },
      {
        year: 2004,
        date: "Julio de 2004",
        title: "El primer minijuego de Roblox",
        description: "El 31 de julio, se crea el minijuego más antiguo conocido de Roblox: 'Spasmotron2 vs. Wimpotron2', creado por el propio David Baszucki.",
        tags: ["Primer Juego", "Historia"],
        icon: "🎮"
      },
      {
        year: 2004,
        date: "Finales de 2004",
        title: "Versiones beta extremadamente básicas",
        description: "Baszucki y Cassel trabajan solos creando las primeras versiones de Roblox. Los avatares no estaban animados y muchas funciones estaban solo en su forma más básica. Crean sus propios juegos para demostrar las capacidades de la plataforma.",
        tags: ["Beta", "Desarrollo"],
        icon: "⚙️"
      },
      {
        year: 2005,
        title: "Beta pública y renombramiento",
        description: "La primera versión jugable de Roblox se lanza en beta. Durante este año se realizan ajustes importantes al motor físico. La plataforma es publicitada en algunos sitios web, atrayendo decenas de jugadores como beta testers.",
        tags: ["Beta", "Pruebas"],
        icon: "🧪"
      },
      {
        year: 2005,
        title: "El nombre 'DynaBlocks' se convierte en 'Roblox'",
        description: "El nombre definitivo 'Roblox' es finalizado. La primera moneda del juego se llamó 'ROBLOX Points', que podía ganarse iniciando sesión o jugando minijuegos.",
        tags: ["Nombre", "Moneda"],
        icon: "💰"
      }
    ]
  },
  {
    id: "launch",
    name: "Lanzamiento Oficial",
    years: "2006 – 2008",
    color: "#cc3300",
    description: "Roblox abre sus puertas al mundo y establece sus bases como plataforma.",
    events: [
      {
        year: 2006,
        date: "1 de septiembre de 2006",
        title: "🚀 Lanzamiento oficial de Roblox",
        description: "Roblox se lanza oficialmente al público el 1 de septiembre de 2006. Roblox Studio también es puesto a disposición ese mismo año. Los primeros juegos creados por la comunidad incluyen juegos de paintball, casas encantadas y trenes en miniatura que los jugadores podían montar.",
        tags: ["Lanzamiento", "Histórico", "Hito"],
        icon: "🚀"
      },
      {
        year: 2006,
        date: "Mediados de 2006",
        title: "Los primeros dos empleados no-fundadores",
        description: "Matt Dusek y John Shedletsky (conocido como 'Telamon') son contratados como los primeros empleados que no son Cassel o Baszucki. Dusek se encarga de los aspectos de comunicación de la plataforma.",
        tags: ["Equipo", "Empleados"],
        icon: "👥"
      },
      {
        year: 2006,
        date: "22 de diciembre de 2006",
        title: "Sistema de Badges (insignias)",
        description: "Se añaden los badges de Roblox el 22 de diciembre de 2006, dando a los jugadores recompensas por sus logros.",
        tags: ["Característica", "Badges"],
        icon: "🏆"
      },
      {
        year: 2007,
        date: "Marzo de 2007",
        title: "Cumplimiento con COPPA y Safe Chat",
        description: "Roblox se vuelve compatible con la ley COPPA (Children's Online Privacy Protection Act) introduciendo el 'Safe Chat' para usuarios menores de 13 años, que limitaba su comunicación a mensajes predefinidos de un menú.",
        tags: ["Seguridad", "COPPA", "Chat"],
        icon: "🛡️"
      },
      {
        year: 2007,
        date: "14 de mayo de 2007",
        title: "Introducción del Robux",
        description: "Los ROBLOX Points originales son reemplazados por el Robux el 14 de mayo de 2007. Esta moneda se convertiría en el corazón de la economía virtual de Roblox.",
        tags: ["Moneda", "Robux", "Economía"],
        icon: "💎"
      },
      {
        year: 2007,
        date: "Agosto de 2007",
        title: "Introducción de los Tickets (Tix) y Builders Club",
        description: "Se introduce una segunda moneda llamada 'Tickets' (o 'Tix') en agosto. El 16 de agosto se lanza el Builders Club, la primera suscripción premium de Roblox, que permitía crear más juegos, vender ropa virtual, eliminar anuncios y ganar Robux diariamente.",
        tags: ["Moneda", "Tickets", "Builders Club", "Premium"],
        icon: "🎟️"
      },
      {
        year: 2008,
        title: "Roblox se vuelve completamente dependiente del UGC",
        description: "En 2008, Roblox Corporation deja de crear activamente sus propios juegos para demostrar las capacidades de la plataforma, convirtiéndose completamente en una plataforma impulsada por contenido generado por usuarios (User-Generated Content).",
        tags: ["UGC", "Comunidad", "Plataforma"],
        icon: "🌐"
      },
      {
        year: 2008,
        title: "RoblEX y el sistema de intercambio de monedas",
        description: "Se establece el sistema RoblEX que permite intercambiar Tickets por Robux. La tasa inicial era de 2 tickets por 1 Robux.",
        tags: ["Economía", "RoblEX", "Monedas"],
        icon: "💹"
      }
    ]
  },
  {
    id: "growth",
    name: "Crecimiento y Expansión",
    years: "2009 – 2012",
    color: "#b85c00",
    description: "Roblox crece rápidamente y añade características que moldean su identidad.",
    events: [
      {
        year: 2009,
        title: "Turbo y Outrageous Builders Club",
        description: "Se añaden dos niveles superiores al Builders Club: Turbo Builders Club y Outrageous Builders Club, ofreciendo más beneficios premium a los jugadores dedicados.",
        tags: ["Premium", "Builders Club"],
        icon: "⭐"
      },
      {
        year: 2009,
        title: "Modo Invitado (Guest Mode)",
        description: "Roblox lanza el Modo Invitado, que permite a los usuarios jugar sin necesidad de crear una cuenta, aunque con funcionalidades limitadas.",
        tags: ["Invitados", "Accesibilidad"],
        icon: "👤"
      },
      {
        year: 2010,
        title: "Renovación de Roblox Studio",
        description: "Roblox Studio es rediseñado para hacerlo más accesible a desarrolladores. La plataforma experimenta un crecimiento significativo de usuarios.",
        tags: ["Studio", "Desarrollo", "Crecimiento"],
        icon: "🔧"
      },
      {
        year: 2011,
        date: "Agosto de 2011",
        title: "Primer anuncio de TV y crecimiento masivo",
        description: "Roblox lanza su primer anuncio con la famosa frase '¡ES GRATIS!'. Para agosto de 2011, Roblox tenía millones de usuarios registrados. El 1 de agosto se celebra el primer evento ROBLOX Rally en San Francisco.",
        tags: ["Publicidad", "Crecimiento", "Evento"],
        icon: "📺"
      },
      {
        year: 2011,
        date: "Diciembre de 2011",
        title: "Primera Hack Week de Roblox",
        description: "Roblox celebra su primera Hack Week en diciembre, un evento anual donde los desarrolladores trabajan en ideas innovadoras para la plataforma.",
        tags: ["Desarrolladores", "Hack Week"],
        icon: "💡"
      },
      {
        year: 2012,
        title: "ROBLOX Game Conference 2012",
        description: "Se celebra la ROBLOX Game Conference 2012, continuando la tradición de reunir a la comunidad.",
        tags: ["Evento", "Comunidad"],
        icon: "🎪"
      },
      {
        year: 2012,
        date: "11 de diciembre de 2012",
        title: "Lanzamiento en iOS",
        description: "El 11 de diciembre de 2012, Roblox lanza su versión completa para iOS, permitiendo a los usuarios jugar juegos desde sus iPhones e iPads, aunque sin acceso a Roblox Studio.",
        tags: ["iOS", "Mobile", "Expansión"],
        icon: "📱"
      },
      {
        year: 2012,
        date: "1 de abril de 2012",
        title: "El gran hackeo del Día de los Inocentes",
        description: "El 1 de abril de 2012, el sitio web de Roblox fue hackeado. Un individuo desconocido logró vandalizar el sitio añadiendo banners con contenido ofensivo. El sitio fue cerrado ese día y recuperado el 2 de abril.",
        tags: ["Hackeo", "Seguridad", "Historia"],
        icon: "🔓"
      }
    ]
  },
  {
    id: "monetization",
    name: "La Era de la Monetización",
    years: "2013 – 2015",
    color: "#c47600",
    description: "Roblox abre las puertas a que los creadores ganen dinero real y se expande a nuevas plataformas.",
    events: [
      {
        year: 2013,
        date: "11 de febrero de 2013",
        title: "Fallecimiento de Erik Cassel",
        description: "El co-fundador de Roblox, Erik Cassel, fallece el 11 de febrero de 2013 tras una larga batalla contra el cáncer. Su legado vive en cada aspecto de la plataforma que ayudó a crear.",
        tags: ["Histórico", "Luto", "Fundador"],
        icon: "🕯️"
      },
      {
        year: 2013,
        title: "BLOXcon 2013 — Conferencias mundiales",
        description: "El ROBLOX BLOXcon 2013 se celebra en Chicago, Londres y Nueva York, además del Virtual BLOXcon 2013, que podía seguirse en vivo. Roblox se convierte en un fenómeno global.",
        tags: ["Evento", "Global", "Comunidad"],
        icon: "🌍"
      },
      {
        year: 2013,
        title: "Iluminación dinámica (Dynamic Lighting)",
        description: "Roblox añade iluminación dinámica en 2013, haciendo que los juegos se vean más realistas e inmersivos. Esta tecnología recibió mejoras constantes en los años siguientes.",
        tags: ["Gráficos", "Motor", "Tecnología"],
        icon: "💡"
      },
      {
        year: 2013,
        date: "24 de septiembre de 2013",
        title: "Precios mínimos en el Marketplace",
        description: "Roblox establece un precio mínimo para la ropa en el marketplace: 10 Robux para camisetas y 20 Robux (o 120 tickets) para camisas y pantalones.",
        tags: ["Economía", "Marketplace"],
        icon: "🛍️"
      },
      {
        year: 2013,
        date: "1 de octubre de 2013",
        title: "Developer Exchange (DevEx) — ¡Gana dinero real!",
        description: "Roblox lanza el programa Developer Exchange (DevEx) el 1 de octubre de 2013. Inicialmente solo disponible para miembros de Outrageous Builders Club, permite a los desarrolladores convertir sus Robux en dinero real. Los pagos iniciales estaban limitados a $500.",
        tags: ["DevEx", "Dinero Real", "Creadores", "Histórico"],
        icon: "💵"
      },
      {
        year: 2014,
        date: "16 de julio de 2014",
        title: "Lanzamiento en Android",
        description: "El 16 de julio de 2014, Roblox lanza su versión para dispositivos Android, completando su presencia en los dos sistemas operativos móviles más importantes.",
        tags: ["Android", "Mobile", "Expansión"],
        icon: "📱"
      },
      {
        year: 2014,
        title: "Animaciones de personajes y herramientas de desarrollo",
        description: "Roblox lanza múltiples actualizaciones a sus herramientas de desarrollo, añadiendo soporte para animaciones de personajes, plugins de Roblox Studio y Developer Stats, que muestra estadísticas detalladas de los juegos.",
        tags: ["Desarrollo", "Herramientas", "Studio"],
        icon: "🎨"
      },
      {
        year: 2015,
        date: "Mayo de 2015",
        title: "Motor de física mejorado y Smooth Terrain",
        description: "En mayo de 2015, Roblox actualiza su motor de física para ser más suave y realista. También se lanza Smooth Terrain (31 de mayo), que mejora drásticamente la fidelidad gráfica del terreno como arena, hierba y agua.",
        tags: ["Gráficos", "Motor", "Terrain"],
        icon: "🏔️"
      },
      {
        year: 2015,
        date: "20 de noviembre de 2015",
        title: "Roblox llega a Xbox One",
        description: "El 20 de noviembre de 2015, Roblox es lanzado en Xbox One con una selección inicial de 15 juegos curados por el equipo de Roblox. Era la primera vez que Roblox llegaba a una consola de videojuegos. Más tarde se lanzó un sistema de aprobación para publicar juegos en la plataforma.",
        tags: ["Xbox", "Consola", "Expansión", "Histórico"],
        icon: "🎮"
      }
    ]
  },
  {
    id: "modernization",
    name: "Modernización y Controversias",
    years: "2016 – 2018",
    color: "#e06000",
    description: "Roblox se reinventa visual y funcionalmente, pero enfrenta sus primeras grandes controversias.",
    events: [
      {
        year: 2016,
        date: "15 de marzo de 2016",
        title: "Anuncio del fin de los Tickets (Tix)",
        description: "David Baszucki anuncia el 15 de marzo que los Tickets (Tix) serían descontinuados en 30 días. Durante ese período, se lanzaron nuevos ítems que solo podían comprarse con Tickets.",
        tags: ["Tickets", "Moneda", "Económia"],
        icon: "📣"
      },
      {
        year: 2016,
        date: "14 de abril de 2016",
        title: "Eliminación definitiva de los Tickets (Tix)",
        description: "El 14 de abril de 2016, los Tickets son eliminados permanentemente de Roblox, junto con el sistema de intercambio de monedas (Trade Currency). Esta decisión generó una enorme controversia en la comunidad, ya que los Tix eran la única moneda gratuita del juego.",
        tags: ["Tickets", "Eliminación", "Controversia"],
        icon: "❌"
      },
      {
        year: 2016,
        date: "Septiembre de 2016",
        title: "Sistema de avatares R15",
        description: "Roblox lanza el sistema R15 al público, que divide el avatar en 15 partes en lugar de las 6 del R6 original, permitiendo animaciones mucho más fluidas y expresivas.",
        tags: ["Avatar", "R15", "Animación"],
        icon: "🏃"
      },
      {
        year: 2016,
        title: "Filtro de texto mejorado y 163 empleados",
        description: "El sistema de Safe Chat basado en mensajes predefinidos es reemplazado por un sistema de filtrado de texto con Community Sift, permitiendo a menores de 13 años escribir mensajes reales. Para diciembre de 2016, Roblox tenía 163 empleados.",
        tags: ["Seguridad", "Chat", "Crecimiento"],
        icon: "🔒"
      },
      {
        year: 2017,
        date: "Enero de 2017",
        title: "Nuevo logo de Roblox",
        description: "Roblox cambia su logo icónico por un diseño más moderno y minimalista. El canal de YouTube oficial lanzó un videoclip musical para presentar el cambio. Este nuevo logo marcó el inicio de la era 'moderna' de Roblox.",
        tags: ["Logo", "Rediseño", "Identidad"],
        icon: "🎨"
      },
      {
        year: 2017,
        title: "Roblox supera los 48 millones de usuarios mensuales",
        description: "Para 2017, Roblox supera los 48 millones de usuarios activos mensuales. Los desarrolladores de hobbyistas ganan colectivamente más de $30 millones ese año a través del programa DevEx.",
        tags: ["Crecimiento", "Estadísticas", "DevEx"],
        icon: "📈"
      },
      {
        year: 2017,
        date: "Octubre de 2017",
        title: "Eliminación del Modo Invitado",
        description: "El modo Invitado es eliminado en octubre de 2017. La razón principal fue que muchos usuarios lo usaban para hacer trampa o para evitar consecuencias por mal comportamiento.",
        tags: ["Invitado", "Moderación"],
        icon: "🚫"
      },
      {
        year: 2018,
        title: "MeepCity: el primer juego con 1 billón de visitas",
        description: "MeepCity se convierte en el primer juego de Roblox en alcanzar 1,000,000,000 (un billón) de visitas, marcando un hito histórico para la plataforma.",
        tags: ["Récord", "Juego", "Hito"],
        icon: "🏆"
      },
      {
        year: 2018,
        title: "Roblox comienza a pagar masivamente a creadores",
        description: "El programa DevEx alcanza nuevas alturas: desde 2018, Roblox ha pagado más de $3.3 mil millones acumulados a creadores hasta 2024. En 2018, los desarrolladores ganaron cientos de millones colectivamente.",
        tags: ["DevEx", "Creadores", "Economía"],
        icon: "💰"
      }
    ]
  },
  {
    id: "explosion",
    name: "La Explosión Global",
    years: "2019 – 2021",
    color: "#e2231a",
    description: "La pandemia catapulta a Roblox a niveles de popularidad nunca vistos, seguido por una histórica salida a bolsa.",
    events: [
      {
        year: 2019,
        date: "Abril de 2019",
        title: "90 millones de usuarios",
        description: "Para abril de 2019, Roblox alcanza los 90 millones de usuarios registrados. La plataforma se convierte en una de las más populares entre los menores de 16 años en Estados Unidos.",
        tags: ["Estadísticas", "Crecimiento"],
        icon: "📊"
      },
      {
        year: 2019,
        title: "Reemplazo del Builders Club por Roblox Premium",
        description: "En 2019, el Builders Club es completamente reemplazado por Roblox Premium, un nuevo sistema de suscripción que entrega Robux mensuales en lugar de diarios, junto con acceso a más características y descuentos.",
        tags: ["Premium", "Builders Club", "Suscripción"],
        icon: "⭐"
      },
      {
        year: 2019,
        title: "Roblox Mobile supera $1 billón en ingresos de por vida",
        description: "En noviembre de 2019, Roblox Mobile supera los $1,000,000,000 en ingresos acumulados en toda su historia en plataformas móviles.",
        tags: ["Mobile", "Ingresos", "Récord"],
        icon: "💵"
      },
      {
        year: 2019,
        title: "Acceso a accesorios UGC para creadores seleccionados",
        description: "Desde 2019, usuarios seleccionados obtienen la capacidad de publicar accesorios para avatares, animaciones y bundles, expandiendo enormemente el catálogo de contenido generado por usuarios.",
        tags: ["UGC", "Avatar", "Creadores"],
        icon: "🎭"
      },
      {
        year: 2020,
        title: "La pandemia de COVID-19 catapulta a Roblox",
        description: "La pandemia de COVID-19 genera un crecimiento explosivo: Roblox añade más de 50 millones de usuarios activos mensuales. Para julio de 2020, al menos 20 juegos habían sido jugados más de 1,000 millones de veces y más de 5,000 juegos tenían más de 1 millón de visitas.",
        tags: ["COVID", "Pandemia", "Boom", "Histórico"],
        icon: "🦠"
      },
      {
        year: 2020,
        title: "5 millones de creadores activos",
        description: "Para 2020, Roblox reporta más de 5 millones de creadores activos en la plataforma. Más de 345,000 desarrolladores ganan dinero a través del programa DevEx. Los creadores generan colectivamente $250 millones en 2020.",
        tags: ["Creadores", "DevEx", "Estadísticas"],
        icon: "🎮"
      },
      {
        year: 2020,
        title: "Ingresos móviles superan $2 mil millones",
        description: "En octubre de 2020, Roblox supera los $2,000,000,000 en gastos de jugadores en plataformas móviles. El cambio del nombre de 'ROBLOX' (todo en mayúsculas) a 'Roblox' también ocurre en 2020.",
        tags: ["Mobile", "Ingresos", "Rebranding"],
        icon: "📱"
      },
      {
        year: 2020,
        title: "Conciertos virtuales en Roblox",
        description: "Roblox se convierte en una plataforma para conciertos virtuales durante la pandemia, albergando eventos masivos que atraen a millones de jugadores simultáneos.",
        tags: ["Conciertos", "Eventos", "Virtual"],
        icon: "🎵"
      },
      {
        year: 2021,
        date: "10 de marzo de 2021",
        title: "🏛️ Roblox sale a bolsa en la NYSE",
        description: "El 10 de marzo de 2021, Roblox Corporation debuta en la Bolsa de Valores de Nueva York (NYSE) bajo el símbolo 'RBLX', alcanzando una valoración de aproximadamente $45,000 millones de dólares en su primer día. Fue una de las mayores IPOs del sector tecnológico de ese año.",
        tags: ["IPO", "NYSE", "RBLX", "Histórico", "Bolsa"],
        icon: "📈"
      },
      {
        year: 2021,
        title: "Roblox compra Guilded por $90 millones",
        description: "En agosto de 2021, Roblox adquiere Guilded, una aplicación de comunicación orientada a gamers, por aproximadamente $90 millones. Guilded compite directamente con Discord.",
        tags: ["Adquisición", "Guilded", "Comunicación"],
        icon: "💬"
      },
      {
        year: 2021,
        title: "Prueba beta del Chat de Voz",
        description: "En agosto de 2021, Roblox comienza a probar el Chat de Voz (Voice Chat) con un grupo selecto de desarrolladores. Esta función requiere verificación de edad y está disponible para mayores de 13 años.",
        tags: ["Voice Chat", "Beta", "Comunicación"],
        icon: "🎙️"
      },
      {
        year: 2021,
        date: "Octubre de 2021",
        title: "La Gran Caída de 3 Días",
        description: "En octubre de 2021, Roblox sufre una caída masiva de sus servidores que deja la plataforma fuera de servicio durante casi 3 días completos, el mayor apagón en su historia. Fue causado por problemas en los módulos del backend.",
        tags: ["Caída", "Servidores", "Histórico"],
        icon: "⚠️"
      },
      {
        year: 2021,
        title: "Los juegos pasan a llamarse 'Experiencias'",
        description: "Roblox cambia oficialmente la denominación de sus 'juegos' a 'experiencias', reflejando la visión de la empresa de ser una plataforma de metaverso más allá de los videojuegos.",
        tags: ["Experiencias", "Metaverso", "Rebranding"],
        icon: "🌐"
      },
      {
        year: 2021,
        title: "Luau: Lenguaje de programación open source",
        description: "En noviembre de 2021, Roblox hace open source su lenguaje de programación Luau (un dialecto de Lua 5.1) bajo la Licencia MIT. Esto permite a la comunidad externa contribuir al desarrollo del lenguaje.",
        tags: ["Luau", "Open Source", "Programación"],
        icon: "💻"
      }
    ]
  },
  {
    id: "metaverse",
    name: "Era del Metaverso",
    years: "2022 – 2024",
    color: "#8b0000",
    description: "Roblox apunta a convertirse en el metaverso definitivo, expandiéndose a nuevas plataformas y tecnologías.",
    events: [
      {
        year: 2022,
        title: "Nuevo logo de Roblox (2022)",
        description: "Roblox presenta un nuevo logo más moderno y limpio en 2022, simplificando su identidad visual para representar mejor la era del metaverso.",
        tags: ["Logo", "Rediseño"],
        icon: "🎨"
      },
      {
        year: 2022,
        title: "Ropa por capas (Layered Clothing)",
        description: "Se lanza el sistema de ropa por capas, que permite a los avatares usar múltiples prendas de ropa que se adaptan dinámicamente a su cuerpo, similar a la ropa real.",
        tags: ["Avatar", "Ropa", "Tecnología"],
        icon: "👗"
      },
      {
        year: 2022,
        title: "Sistema anti-cheat Byfron",
        description: "Roblox integra el sistema anti-cheat Byfron, adquirido para combatir la creciente presencia de hackers y tramposos en la plataforma.",
        tags: ["Seguridad", "Anti-cheat", "Byfron"],
        icon: "🛡️"
      },
      {
        year: 2022,
        title: "Creadores ganan $623.9 millones",
        description: "En 2022, los participantes del programa DevEx ganaron colectivamente $623.9 millones a través del programa, reflejando el tamaño masivo de la economía de Roblox.",
        tags: ["DevEx", "Economía", "Creadores"],
        icon: "💰"
      },
      {
        year: 2023,
        date: "Septiembre de 2023",
        title: "Roblox llega a Meta Quest (VR)",
        description: "En septiembre de 2023, Roblox se lanza en Meta Quest 2 y Meta Quest Pro, llevando la experiencia de Roblox a la realidad virtual por primera vez.",
        tags: ["VR", "Meta Quest", "Realidad Virtual", "Expansión"],
        icon: "🥽"
      },
      {
        year: 2023,
        date: "10 de octubre de 2023",
        title: "Roblox llega a PlayStation 4",
        description: "El 10 de octubre de 2023, Roblox se lanza oficialmente en PlayStation 4, expandiendo su presencia en consolas junto a Xbox One.",
        tags: ["PS4", "PlayStation", "Consola", "Expansión"],
        icon: "🎮"
      },
      {
        year: 2023,
        title: "Publicidad en la plataforma (oculta para menores de 13)",
        description: "Roblox introduce un sistema de publicidad en la plataforma en 2023. Sin embargo, desde marzo de 2023, los anuncios son ocultados para todos los usuarios menores de 13 años.",
        tags: ["Publicidad", "Menores", "Monetización"],
        icon: "📣"
      },
      {
        year: 2024,
        title: "Despidos masivos: 660 empleados",
        description: "En enero de 2024, Roblox despide a aproximadamente 660 empleados, alrededor del 28% de su fuerza laboral total. La empresa justificó la decisión como necesaria para alcanzar la rentabilidad a largo plazo.",
        tags: ["Despidos", "Reestructuración", "Polémico"],
        icon: "📉"
      },
      {
        year: 2024,
        title: "79.5 millones de usuarios activos diarios",
        description: "Para 2024, Roblox alcanza un promedio de 79.5 millones de usuarios activos diarios. Los ingresos alcanzan $3,600 millones y los creadores reciben $923 millones a través del DevEx.",
        tags: ["Estadísticas", "Récord", "Crecimiento"],
        icon: "📊"
      },
      {
        year: 2024,
        title: "$3.3 mil millones pagados a creadores desde 2018",
        description: "Acumulativamente desde 2018 hasta finales de 2024, Roblox ha pagado más de $3,300 millones a los creadores de la plataforma a través del programa Developer Exchange.",
        tags: ["DevEx", "Creadores", "Hito"],
        icon: "💵"
      },
      {
        year: 2024,
        date: "Agosto de 2024",
        title: "Turquía bloquea Roblox",
        description: "En agosto de 2024, Turquía bloquea el acceso a Roblox citando preocupaciones sobre 'explotación infantil'. Esta sería la primera de varias prohibiciones en países del Medio Oriente y Asia.",
        tags: ["Censura", "Controversia", "Seguridad"],
        icon: "🚫"
      }
    ]
  },
  {
    id: "future",
    name: "Presente y Futuro",
    years: "2025 – Hoy",
    color: "#3d0000",
    description: "Roblox en su era más ambiciosa: inteligencia artificial, récords económicos y un futuro incierto.",
    events: [
      {
        year: 2025,
        date: "Febrero de 2025",
        title: "85.3 millones de usuarios activos diarios",
        description: "Para febrero de 2025, Roblox reporta un promedio de 85.3 millones de usuarios activos diarios, siendo la mitad de todos los niños estadounidenses menores de 16 años usuarios de la plataforma.",
        tags: ["Estadísticas", "Récord"],
        icon: "📊"
      },
      {
        year: 2025,
        date: "Marzo de 2025",
        title: "Roblox Cube: IA generativa para creadores",
        description: "En marzo de 2025, Roblox presenta 'Roblox Cube', un sistema de inteligencia artificial generativa que permite a los creadores generar objetos 3D completamente funcionales a partir de texto, incluyendo un coche completamente conducible generado por IA.",
        tags: ["IA", "Generativa", "Creadores", "Futuro"],
        icon: "🤖"
      },
      {
        year: 2025,
        title: "Traducción de voz en tiempo real",
        description: "Roblox implementa la traducción de voz en tiempo real, permitiendo a jugadores de diferentes países comunicarse en sus idiomas nativos durante el chat de voz, con latencia casi nula.",
        tags: ["IA", "Idiomas", "Voice Chat", "Innovación"],
        icon: "🗣️"
      },
      {
        year: 2025,
        date: "Q1 2025",
        title: "$1,035 millones en ingresos — primer trimestre billonario",
        description: "En el primer trimestre de 2025, Roblox reporta ingresos de $1,035 millones, superando la barrera de los $1,000 millones por trimestre por primera vez. Se reportan 97.8 millones de usuarios activos diarios.",
        tags: ["Ingresos", "Récord", "Estadísticas"],
        icon: "💰"
      },
      {
        year: 2025,
        title: "$1,000 millones pagados a creadores en 2025",
        description: "Por primera vez en la historia, Roblox paga más de $1,000 millones a sus creadores en un solo año calendario a través del programa Developer Exchange, superando los $923 millones de 2024.",
        tags: ["DevEx", "Récord", "Creadores", "Hito"],
        icon: "🏆"
      },
      {
        year: 2025,
        title: "Investigación de la SEC (Comisión de Bolsa)",
        description: "En febrero de 2025, la SEC (Securities and Exchange Commission) confirma una 'investigación activa' sobre Roblox Corporation, relacionada con presuntas irregularidades en métricas reportadas a inversores.",
        tags: ["SEC", "Investigación", "Polémico"],
        icon: "⚖️"
      },
      {
        year: 2025,
        date: "Diciembre de 2025",
        title: "Rusia bloquea Roblox",
        description: "En diciembre de 2025, Rusia bloquea el acceso a Roblox, sumándose a la lista de países que han restringido la plataforma por preocupaciones sobre seguridad infantil.",
        tags: ["Censura", "Rusia", "Controversia"],
        icon: "🚫"
      },
      {
        year: 2025,
        title: "Conexiones de confianza y sistema de amigos renovado",
        description: "Roblox implementa el sistema de 'Trusted Connections' (Conexiones de Confianza) que permite a los usuarios verificados enviarse mensajes sin filtrar. Los amigos pasan a llamarse oficialmente 'conexiones' en 2025.",
        tags: ["Seguridad", "Social", "Amigos"],
        icon: "🤝"
      },
      {
        year: 2026,
        title: "Optimización para dispositivos de bajo gama",
        description: "Roblox optimiza su motor para dispositivos móviles de bajo rendimiento en mercados emergentes, expandiendo masivamente su audiencia potencial a nivel global.",
        tags: ["Expansión", "Mobile", "Global", "Futuro"],
        icon: "🌍"
      }
    ]
  }
];

export const robloxStats = [
  { label: "Usuarios Activos Diarios (2025)", value: "97.8M+", icon: "👥" },
  { label: "Ingresos Anuales (2024)", value: "$3.6B", icon: "💰" },
  { label: "Pagado a Creadores (2024)", value: "$923M", icon: "💎" },
  { label: "Año de Fundación", value: "2004", icon: "🎂" },
  { label: "Experiencias en la Plataforma", value: "+40M", icon: "🎮" },
  { label: "Países Disponible", value: "+180", icon: "🌍" },
  { label: "Valoración en IPO (2021)", value: "$45B", icon: "📈" },
  { label: "Creadores con DevEx", value: "+24,500", icon: "🏆" },
];

export const robloxFacts = [
  "El nombre 'Roblox' combina 'robots' y 'blocks' (bloques).",
  "La mitad de todos los niños estadounidenses menores de 16 años juegan Roblox.",
  "El sonido 'OOF' original fue creado para un videojuego llamado 'Messiah' en el año 2000.",
  "Roblox usa Luau, un dialecto del lenguaje de programación Lua, open source desde 2021.",
  "El primer juego en alcanzar 1 billón de visitas fue MeepCity en 2018.",
  "La gran caída de 2021 dejó a Roblox fuera de servicio por casi 3 días completos.",
  "Erik Cassel, co-fundador de Roblox, falleció el 11 de febrero de 2013.",
  "Roblox compró la app de comunicación Guilded por $90 millones en 2021.",
  "Los Tickets (Tix) fueron eliminados el 14 de abril de 2016, causando gran controversia.",
  "Roblox está disponible en Windows, macOS, iOS, Android, Xbox One, Meta Quest y PlayStation 4.",
];
