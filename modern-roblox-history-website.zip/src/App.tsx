import { useState, useEffect, useRef } from 'react';
import { robloxEras, robloxStats, robloxFacts, type Era, type HistoryEvent } from './data/robloxHistory';
import CommentsSection from './components/CommentsSection';

// Particle component
function Particles() {
  const colors = ['#e2231a', '#ff6b35', '#ff3333', '#b01010', '#ff8c00'];
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    size: `${Math.random() * 6 + 3}px`,
    duration: `${Math.random() * 15 + 10}s`,
    delay: `${Math.random() * 15}s`,
    color: colors[Math.floor(Math.random() * colors.length)],
    opacity: Math.random() * 0.5 + 0.2,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {particles.map(p => (
        <div
          key={p.id}
          className="particle"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            background: p.color,
            animationDuration: p.duration,
            animationDelay: p.delay,
            opacity: p.opacity,
            bottom: '-20px',
          }}
        />
      ))}
    </div>
  );
}

// Floating cubes decoration
function FloatingCubes() {
  const cubes = Array.from({ length: 6 }, (_, i) => ({
    id: i,
    left: `${10 + i * 15}%`,
    top: `${Math.random() * 80 + 10}%`,
    delay: `${i * 1.2}s`,
    size: `${Math.random() * 20 + 15}px`,
  }));

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {cubes.map(c => (
        <div
          key={c.id}
          style={{
            position: 'absolute',
            left: c.left,
            top: c.top,
            width: c.size,
            height: c.size,
            background: 'linear-gradient(135deg, rgba(226,35,26,0.3), rgba(139,0,0,0.2))',
            border: '1px solid rgba(226,35,26,0.3)',
            transform: 'rotate(45deg)',
            animation: `rotateCube ${8 + parseFloat(c.delay)}s linear infinite`,
            animationDelay: c.delay,
          }}
        />
      ))}
    </div>
  );
}

// Navbar
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const links = [
    { href: '#inicio', label: 'Inicio' },
    { href: '#estadisticas', label: 'Estadísticas' },
    { href: '#historia', label: 'Historia' },
    { href: '#datos', label: 'Curiosidades' },
    { href: '#comentarios', label: 'Comentarios' },
  ];

  return (
    <nav
      className={`navbar fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'py-3' : 'py-5'}`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#inicio" className="roblox-font text-2xl text-white glow-red flex items-center gap-2">
          <span className="text-red-500">R</span>OBLOX
        </a>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-8">
          {links.map(l => (
            <a
              key={l.href}
              href={l.href}
              className="nav-link text-gray-300 hover:text-red-400 text-sm font-semibold transition-colors"
            >
              {l.label}
            </a>
          ))}
        </div>

        {/* Mobile menu btn */}
        <button
          className="md:hidden text-gray-300 hover:text-red-400 transition-colors"
          onClick={() => setMobileOpen(p => !p)}
        >
          {mobileOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-red-900/30 mt-3 py-4 px-6 space-y-4">
          {links.map(l => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setMobileOpen(false)}
              className="block text-gray-300 hover:text-red-400 text-sm font-semibold transition-colors"
            >
              {l.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}

// Hero section
function Hero() {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center overflow-hidden hero-bg scanlines"
      style={{
        backgroundImage: 'url(/images/roblox-hero-bg.jpg)',
        backgroundAttachment: 'fixed',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-[#0a0a0f]" />
      <div className="absolute inset-0 bg-gradient-to-r from-red-950/30 via-transparent to-red-950/30" />

      <FloatingCubes />

      <div className="relative z-10 text-center max-w-5xl mx-auto px-6">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-900/30 border border-red-700/50 text-red-400 text-sm font-bold mb-8 pulse-red">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse inline-block"></span>
          Historia Completa · 2004 – Hoy
        </div>

        {/* Main title */}
        <h1 className="roblox-font text-7xl md:text-9xl font-bold mb-2 leading-none">
          <span className="text-red-500 glow-red">R</span>
          <span className="text-white">OBLOX</span>
        </h1>

        <div className="w-32 h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent mx-auto mb-8" />

        <h2 className="text-xl md:text-2xl text-gray-300 font-semibold mb-4">
          La Historia Más Completa del Universo Roblox
        </h2>
        <p className="text-gray-400 text-base md:text-lg max-w-2xl mx-auto mb-12 leading-relaxed">
          Desde los primeros bloques digitales de 2004 hasta los récords históricos de 2025.
          Más de 20 años de historia, datos confirmados, hitos y momentos que cambiaron el gaming para siempre.
        </p>

        {/* CTA buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#historia"
            className="roblox-btn px-8 py-4 text-base font-bold flex items-center justify-center gap-2"
          >
            <span>📖</span> Explorar la Historia
          </a>
          <a
            href="#estadisticas"
            className="px-8 py-4 rounded-lg text-base font-bold border border-red-700/50 text-red-400 hover:bg-red-900/20 transition-all duration-300 flex items-center justify-center gap-2"
          >
            <span>📊</span> Ver Estadísticas
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-gray-600 text-xs">Desplázate para explorar</span>
          <div className="w-5 h-8 border border-gray-600 rounded-full flex items-start justify-center p-1">
            <div className="w-1 h-2 bg-red-500 rounded-full animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}

// Stats section
function StatsSection() {
  return (
    <section id="estadisticas" className="py-20 px-6 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0d0005] to-[#0a0a0f] pointer-events-none" />
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-14 reveal" data-reveal>
          <div className="inline-flex items-center gap-2 tag-badge mb-4">
            <span>📊</span> EN NÚMEROS
          </div>
          <h2 className="roblox-font text-4xl md:text-5xl font-bold text-white mb-4">
            Roblox en <span className="gradient-text">Cifras</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Los números que definen una de las plataformas más grandes del mundo
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {robloxStats.map((stat, i) => (
            <div
              key={i}
              className="era-card rounded-2xl p-6 text-center reveal"
              data-reveal
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="text-3xl mb-3">{stat.icon}</div>
              <div className="stat-number text-3xl md:text-4xl mb-2">{stat.value}</div>
              <div className="text-gray-500 text-xs font-semibold leading-tight">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Era card
function EraCard({ era, index, onClick }: { era: Era; index: number; onClick: () => void }) {
  return (
    <div
      className="era-card rounded-2xl p-6 cursor-pointer reveal"
      data-reveal
      style={{ transitionDelay: `${index * 0.1}s` }}
      onClick={onClick}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <div
            className="text-xs font-bold px-3 py-1 rounded-full mb-3 inline-block"
            style={{
              background: `${era.color}22`,
              border: `1px solid ${era.color}55`,
              color: era.color,
            }}
          >
            {era.years}
          </div>
          <h3 className="text-white font-bold text-xl leading-tight">{era.name}</h3>
        </div>
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm shrink-0"
          style={{ background: `${era.color}33`, border: `1px solid ${era.color}44` }}
        >
          {era.events.length}
        </div>
      </div>
      <p className="text-gray-400 text-sm leading-relaxed mb-4">{era.description}</p>
      <div className="flex items-center text-red-400 text-sm font-semibold">
        <span>Ver {era.events.length} eventos</span>
        <span className="ml-2">→</span>
      </div>
    </div>
  );
}

// Event card in timeline
function EventCard({ event, index }: { event: HistoryEvent; index: number }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div
      className="relative pl-8 reveal"
      data-reveal
      style={{ transitionDelay: `${index * 0.05}s` }}
    >
      {/* Timeline dot */}
      <div className="absolute left-0 top-2 w-4 h-4 rounded-full bg-red-600 border-2 border-red-900 glow-box z-10" />
      {/* Timeline line */}
      <div className="absolute left-[7px] top-6 bottom-0 w-0.5 bg-gradient-to-b from-red-800/60 to-transparent" />

      <div
        className="comment-card p-5 mb-4 cursor-pointer"
        onClick={() => setExpanded(p => !p)}
      >
        <div className="flex items-start gap-3">
          <span className="text-2xl shrink-0 mt-0.5">{event.icon || '📌'}</span>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="year-badge text-xs px-2 py-0.5 rounded text-white font-bold">
                {event.date || event.year}
              </span>
              {event.tags?.slice(0, 2).map(tag => (
                <span key={tag} className="tag-badge text-xs">{tag}</span>
              ))}
            </div>
            <h4 className="text-white font-bold text-base leading-tight">{event.title}</h4>
            {expanded && (
              <p className="text-gray-400 text-sm mt-2 leading-relaxed">{event.description}</p>
            )}
            {!expanded && (
              <p className="text-gray-500 text-xs mt-1">Haz clic para leer más →</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Era detail modal
function EraModal({ era, onClose }: { era: Era; onClose: () => void }) {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === modalRef.current) onClose();
  };

  return (
    <div
      ref={modalRef}
      className="modal-overlay fixed inset-0 z-50 flex items-start justify-center overflow-y-auto py-8 px-4"
      onClick={handleOverlayClick}
    >
      <div className="relative max-w-3xl w-full bg-[#0d0d14] border border-red-900/40 rounded-3xl p-8 shadow-2xl">
        {/* Close btn */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-red-900/40 text-white hover:bg-red-700 transition-all duration-200 flex items-center justify-center font-bold"
        >
          ✕
        </button>

        {/* Era header */}
        <div className="mb-8">
          <div
            className="text-xs font-bold px-3 py-1 rounded-full mb-3 inline-block"
            style={{
              background: `${era.color}22`,
              border: `1px solid ${era.color}55`,
              color: era.color,
            }}
          >
            {era.years}
          </div>
          <h2 className="roblox-font text-3xl md:text-4xl text-white font-bold mb-2">{era.name}</h2>
          <p className="text-gray-400 text-sm leading-relaxed">{era.description}</p>
        </div>

        {/* Timeline events */}
        <div className="relative">
          {/* Background line */}
          <div className="absolute left-[7px] top-0 bottom-0 w-0.5 timeline-line" />
          {era.events.map((event, i) => (
            <EventCard key={i} event={event} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}

// History section
function HistorySection() {
  const [selectedEra, setSelectedEra] = useState<Era | null>(null);

  return (
    <section id="historia" className="py-24 px-6 relative">
      <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none" />
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-16 reveal" data-reveal>
          <div className="inline-flex items-center gap-2 tag-badge mb-4">
            <span>📚</span> HISTORIA COMPLETA
          </div>
          <h2 className="roblox-font text-4xl md:text-6xl font-bold text-white mb-4">
            20 Años de <span className="gradient-text">Historia</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Selecciona una era para explorar todos los eventos, hitos y datos confirmados de esa época en la historia de Roblox.
          </p>
        </div>

        {/* Eras grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {robloxEras.map((era, i) => (
            <EraCard key={era.id} era={era} index={i} onClick={() => setSelectedEra(era)} />
          ))}
        </div>

        {/* Full timeline teaser */}
        <div className="mt-20 reveal" data-reveal>
          <div className="era-card rounded-3xl p-8 text-center neon-border">
            <div className="text-5xl mb-4">⏳</div>
            <h3 className="roblox-font text-3xl text-white font-bold mb-3">
              Línea de Tiempo Completa
            </h3>
            <p className="text-gray-400 mb-6 max-w-xl mx-auto">
              Haz clic en cualquier era para ver la línea de tiempo detallada con todos los eventos, fechas exactas y datos confirmados.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              {robloxEras.map(era => (
                <button
                  key={era.id}
                  onClick={() => setSelectedEra(era)}
                  className="px-4 py-2 rounded-full text-xs font-bold transition-all duration-300 hover:scale-105"
                  style={{
                    background: `${era.color}22`,
                    border: `1px solid ${era.color}55`,
                    color: era.color,
                  }}
                >
                  {era.years} — {era.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {selectedEra && <EraModal era={selectedEra} onClose={() => setSelectedEra(null)} />}
    </section>
  );
}

// Facts section
function FactsSection() {
  return (
    <section id="datos" className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0f] via-[#0f0004] to-[#0a0a0f] pointer-events-none" />
      {/* Decorative large R */}
      <div
        className="absolute right-0 top-1/2 -translate-y-1/2 text-[30rem] font-black text-red-950/20 leading-none select-none pointer-events-none roblox-font"
        style={{ right: '-5rem' }}
      >
        R
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-14 reveal" data-reveal>
          <div className="inline-flex items-center gap-2 tag-badge mb-4">
            <span>💡</span> DATOS CURIOSOS
          </div>
          <h2 className="roblox-font text-4xl md:text-5xl font-bold text-white mb-4">
            ¿Sabías que...? <span className="gradient-text">Curiosidades</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Hechos sorprendentes y poco conocidos sobre la historia de Roblox
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {robloxFacts.map((fact, i) => (
            <div
              key={i}
              className="era-card rounded-2xl p-6 flex items-start gap-4 reveal"
              data-reveal
              style={{ transitionDelay: `${i * 0.08}s` }}
            >
              <div className="w-10 h-10 rounded-xl bg-red-900/40 border border-red-800/50 flex items-center justify-center text-red-400 font-bold text-lg shrink-0">
                {i + 1}
              </div>
              <p className="text-gray-300 text-sm leading-relaxed">{fact}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Founders section
function FoundersSection() {
  return (
    <section className="py-24 px-6 relative">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-14 reveal" data-reveal>
          <div className="inline-flex items-center gap-2 tag-badge mb-4">
            <span>👨‍💼</span> FUNDADORES
          </div>
          <h2 className="roblox-font text-4xl md:text-5xl font-bold text-white mb-4">
            Los <span className="gradient-text">Creadores</span> de Roblox
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* David Baszucki */}
          <div className="era-card rounded-3xl p-8 text-center reveal" data-reveal>
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-red-700 to-red-900 flex items-center justify-center text-5xl mx-auto mb-5 border-4 border-red-800/50">
              👨‍💻
            </div>
            <h3 className="text-white font-bold text-2xl mb-1">David Baszucki</h3>
            <p className="text-red-400 text-sm font-semibold mb-4">Co-Fundador & CEO</p>
            <p className="text-gray-400 text-sm leading-relaxed">
              Nació el 20 de enero de 1963. Fundó Knowledge Revolution en 1989 y creó Roblox junto a Erik Cassel en 2004.
              Apodado "Builderman" en la plataforma, es el usuario #1 de Roblox. Continúa siendo el CEO de Roblox Corporation.
              Su visión fue crear un mundo virtual donde la creatividad no tuviera límites.
            </p>
          </div>

          {/* Erik Cassel */}
          <div className="era-card rounded-3xl p-8 text-center reveal" data-reveal style={{ transitionDelay: '0.15s' }}>
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center text-5xl mx-auto mb-5 border-4 border-gray-700/50">
              🌟
            </div>
            <h3 className="text-white font-bold text-2xl mb-1">Erik Cassel</h3>
            <p className="text-red-400 text-sm font-semibold mb-4">Co-Fundador (1977 – 2013)</p>
            <p className="text-gray-400 text-sm leading-relaxed">
              Co-fundó Roblox junto a David Baszucki en 2004 tras trabajar juntos en Knowledge Revolution.
              Fue pieza clave en el desarrollo técnico de la plataforma durante sus primeros años.
              Lamentablemente falleció el <strong className="text-gray-300">11 de febrero de 2013</strong> tras una larga batalla contra el cáncer.
              Su legado vive en cada aspecto de Roblox.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

// Platforms section
function PlatformsSection() {
  const platforms = [
    { name: 'Windows', icon: '💻', date: '1 Sep 2006', color: '#0078d4' },
    { name: 'macOS', icon: '🍎', date: '1 Sep 2006', color: '#555' },
    { name: 'iOS', icon: '📱', date: '11 Dic 2012', color: '#007AFF' },
    { name: 'Android', icon: '🤖', date: '16 Jul 2014', color: '#3DDC84' },
    { name: 'Xbox One', icon: '🎮', date: '20 Nov 2015', color: '#107C10' },
    { name: 'Meta Quest', icon: '🥽', date: 'Sep 2023', color: '#0064E0' },
    { name: 'PlayStation 4', icon: '🕹️', date: '10 Oct 2023', color: '#003087' },
  ];

  return (
    <section className="py-24 px-6 relative">
      <div className="absolute inset-0 bg-grid opacity-15 pointer-events-none" />
      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-14 reveal" data-reveal>
          <div className="inline-flex items-center gap-2 tag-badge mb-4">
            <span>📲</span> PLATAFORMAS
          </div>
          <h2 className="roblox-font text-4xl md:text-5xl font-bold text-white mb-4">
            Disponible en <span className="gradient-text">Todas Partes</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Roblox ha expandido su presencia a lo largo de los años a múltiples dispositivos y plataformas
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {platforms.map((p, i) => (
            <div
              key={i}
              className="era-card rounded-2xl p-5 text-center reveal"
              data-reveal
              style={{ transitionDelay: `${i * 0.08}s` }}
            >
              <div className="text-4xl mb-3">{p.icon}</div>
              <div className="text-white font-bold text-sm mb-1">{p.name}</div>
              <div
                className="text-xs px-2 py-0.5 rounded-full inline-block font-semibold"
                style={{ background: `${p.color}22`, color: p.color, border: `1px solid ${p.color}44` }}
              >
                {p.date}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  return (
    <footer className="relative border-t border-red-900/30 py-12 px-6">
      <div className="max-w-5xl mx-auto text-center">
        <div className="roblox-font text-4xl text-white mb-2">
          <span className="text-red-500">R</span>OBLOX
        </div>
        <p className="text-gray-600 text-sm mb-4">
          Historia Completa de Roblox — Información confirmada y documentada
        </p>
        <div className="w-24 h-0.5 bg-gradient-to-r from-transparent via-red-700 to-transparent mx-auto mb-6" />
        <p className="text-gray-700 text-xs mb-2">
          Esta página es un proyecto fan no oficial. Roblox™ es una marca registrada de Roblox Corporation.
        </p>
        <p className="text-gray-700 text-xs">
          Información recopilada de Wikipedia, Roblox Wiki, y fuentes oficiales de Roblox Corporation.
        </p>

        {/* Created by Night */}
        <div className="mt-8">
          <a
            href="https://www.youtube.com/@NightMKV"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-gray-500 hover:text-red-400 transition-all duration-300 text-sm font-semibold group"
          >
            <span className="w-6 h-6 rounded-full bg-red-900/40 border border-red-800/50 flex items-center justify-center text-xs group-hover:bg-red-700/50 transition-colors">
              🎬
            </span>
            Creado por Night
          </a>
        </div>
      </div>
    </footer>
  );
}

// Scroll reveal hook
function useScrollReveal() {
  useEffect(() => {
    const elements = document.querySelectorAll('[data-reveal]');

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    elements.forEach(el => {
      el.classList.add('reveal');
      observer.observe(el);
    });

    return () => observer.disconnect();
  });
}

// Creator badge (fixed corner)
function CreatorBadge() {
  return (
    <a
      href="https://www.youtube.com/@NightMKV"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-40 group"
    >
      <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-black/80 border border-red-700/50 backdrop-blur-md text-red-400 text-xs font-bold hover:border-red-500 hover:text-red-300 transition-all duration-300 shadow-lg hover:shadow-red-900/30">
        <span className="text-base">🎬</span>
        <span>Creado por Night</span>
        <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">↗</span>
      </div>
    </a>
  );
}

// Main App
export default function App() {
  useScrollReveal();

  return (
    <div className="min-h-screen bg-[#0a0a0f] relative">
      <Particles />
      <Navbar />
      <Hero />
      <StatsSection />
      <HistorySection />
      <FoundersSection />
      <PlatformsSection />
      <FactsSection />
      <CommentsSection />
      <Footer />
      <CreatorBadge />
    </div>
  );
}
