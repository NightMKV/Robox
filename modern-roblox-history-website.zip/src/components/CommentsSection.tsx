import { useState, useEffect, useRef } from 'react';

interface Comment {
  id: string;
  author: string;
  text: string;
  date: string;
  timestamp: number;
}

const ADMIN_PASSWORD = "Night2024Admin#";
const STORAGE_KEY = "roblox_history_comments";

function loadComments(): Comment[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function saveComments(comments: Comment[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(comments));
}

export default function CommentsSection() {
  const [comments, setComments] = useState<Comment[]>(loadComments);
  const [author, setAuthor] = useState('');
  const [text, setText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [adminMode, setAdminMode] = useState(false);
  const [adminInput, setAdminInput] = useState('');
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminError, setAdminError] = useState('');
  const textRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    saveComments(comments);
  }, [comments]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) {
      setErrorMsg('Por favor escribe un comentario.');
      return;
    }
    if (text.trim().length < 5) {
      setErrorMsg('El comentario es demasiado corto.');
      return;
    }
    if (text.trim().length > 500) {
      setErrorMsg('El comentario no puede superar los 500 caracteres.');
      return;
    }

    setSubmitting(true);
    setErrorMsg('');

    const newComment: Comment = {
      id: Date.now().toString() + Math.random().toString(36).slice(2),
      author: author.trim() || 'Anónimo',
      text: text.trim(),
      date: new Date().toLocaleDateString('es-ES', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      timestamp: Date.now(),
    };

    setTimeout(() => {
      setComments(prev => [newComment, ...prev]);
      setAuthor('');
      setText('');
      setSubmitting(false);
      setSuccessMsg('¡Comentario publicado! 🎉');
      setTimeout(() => setSuccessMsg(''), 3000);
    }, 600);
  };

  const handleAdminLogin = () => {
    if (adminInput === ADMIN_PASSWORD) {
      setAdminMode(true);
      setAdminError('');
      setAdminInput('');
      setShowAdminPanel(false);
    } else {
      setAdminError('Contraseña incorrecta.');
    }
  };

  const handleDelete = (id: string) => {
    setComments(prev => prev.filter(c => c.id !== id));
  };

  const handleDeleteAll = () => {
    if (window.confirm('¿Eliminar TODOS los comentarios?')) {
      setComments([]);
    }
  };

  const formatDate = (c: Comment) => c.date;

  return (
    <section id="comentarios" className="py-24 px-4 relative">
      <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
      <div className="max-w-4xl mx-auto relative z-10">

        {/* Header */}
        <div className="text-center mb-14 reveal" data-reveal>
          <div className="inline-flex items-center gap-2 tag-badge mb-4">
            <span>💬</span> COMUNIDAD
          </div>
          <h2 className="roblox-font text-4xl md:text-5xl font-bold text-white mb-4">
            Deja tu <span className="gradient-text">Comentario</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Comparte tu opinión sobre la historia de Roblox. No necesitas registrarte — ¡es completamente anónimo!
          </p>
        </div>

        {/* Admin toggle */}
        <div className="flex justify-end mb-6">
          {!adminMode ? (
            <button
              onClick={() => setShowAdminPanel(p => !p)}
              className="text-xs text-gray-600 hover:text-red-500 transition-colors duration-300 px-3 py-1 rounded border border-transparent hover:border-red-900"
            >
              🔐 Admin
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <span className="text-xs text-green-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-green-400 inline-block animate-pulse"></span>
                Modo Admin activo
              </span>
              <button
                onClick={() => setAdminMode(false)}
                className="text-xs text-red-500 hover:text-red-400 border border-red-900 rounded px-2 py-1 transition-colors"
              >
                Salir
              </button>
              {comments.length > 0 && (
                <button
                  onClick={handleDeleteAll}
                  className="text-xs text-red-500 hover:text-red-400 border border-red-900 rounded px-2 py-1 transition-colors"
                >
                  🗑️ Borrar todo
                </button>
              )}
            </div>
          )}
        </div>

        {/* Admin panel */}
        {showAdminPanel && !adminMode && (
          <div className="mb-8 p-6 rounded-xl neon-border bg-black/50 animate-fadeIn">
            <h3 className="text-white font-bold mb-3 flex items-center gap-2">
              <span>🔐</span> Acceso de Administrador
            </h3>
            <div className="flex gap-3">
              <input
                type="password"
                value={adminInput}
                onChange={e => setAdminInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleAdminLogin()}
                placeholder="Contraseña de administrador"
                className="roblox-input flex-1 px-4 py-2 text-sm"
              />
              <button onClick={handleAdminLogin} className="roblox-btn px-5 py-2 text-sm">
                Entrar
              </button>
            </div>
            {adminError && <p className="text-red-400 text-sm mt-2">{adminError}</p>}
          </div>
        )}

        {/* Comment form */}
        <div className="era-card rounded-2xl p-8 mb-10 reveal" data-reveal>
          <h3 className="text-white font-bold text-xl mb-6 flex items-center gap-2">
            <span className="text-2xl">✍️</span> Nuevo Comentario
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-gray-400 text-sm font-semibold mb-2 block">
                Nombre (opcional)
              </label>
              <input
                type="text"
                value={author}
                onChange={e => setAuthor(e.target.value)}
                placeholder="Tu nombre o apodo (deja en blanco para ser Anónimo)"
                maxLength={50}
                className="roblox-input w-full px-4 py-3 text-sm"
              />
            </div>
            <div>
              <label className="text-gray-400 text-sm font-semibold mb-2 block">
                Comentario <span className="text-red-500">*</span>
              </label>
              <textarea
                ref={textRef}
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="¿Qué piensas sobre la historia de Roblox? ¿Tienes algún recuerdo especial?"
                rows={4}
                maxLength={500}
                className="roblox-input w-full px-4 py-3 text-sm resize-none"
                required
              />
              <div className="flex justify-between mt-1">
                <span className="text-xs text-gray-600">Máximo 500 caracteres</span>
                <span className={`text-xs ${text.length > 450 ? 'text-red-400' : 'text-gray-600'}`}>
                  {text.length}/500
                </span>
              </div>
            </div>

            {errorMsg && (
              <div className="bg-red-900/30 border border-red-700 rounded-lg px-4 py-3 text-red-400 text-sm">
                ⚠️ {errorMsg}
              </div>
            )}
            {successMsg && (
              <div className="bg-green-900/30 border border-green-700 rounded-lg px-4 py-3 text-green-400 text-sm">
                ✅ {successMsg}
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <p className="text-gray-600 text-xs">
                🛡️ Comentarios moderados para eliminar contenido inapropiado
              </p>
              <button
                type="submit"
                disabled={submitting}
                className="roblox-btn px-8 py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {submitting ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin inline-block"></span>
                    Publicando...
                  </>
                ) : (
                  <>
                    <span>📤</span> Publicar Comentario
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Comments list */}
        <div>
          <div className="flex items-center gap-3 mb-6">
            <h3 className="text-white font-bold text-xl">
              Comentarios
            </h3>
            <span className="tag-badge">{comments.length}</span>
          </div>

          {comments.length === 0 ? (
            <div className="text-center py-16 text-gray-600">
              <div className="text-5xl mb-4">💬</div>
              <p className="text-lg">¡Sé el primero en comentar!</p>
              <p className="text-sm mt-2">Comparte tus pensamientos sobre la historia de Roblox</p>
            </div>
          ) : (
            <div className="space-y-4">
              {comments.map((comment, index) => (
                <div
                  key={comment.id}
                  className="comment-card p-5 relative group"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-start gap-4">
                    {/* Avatar */}
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-700 to-red-900 flex items-center justify-center text-white font-bold text-sm shrink-0">
                      {comment.author.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-white font-bold text-sm">{comment.author}</span>
                        <span className="text-gray-600 text-xs">{formatDate(comment)}</span>
                      </div>
                      <p className="text-gray-300 text-sm leading-relaxed break-words">
                        {comment.text}
                      </p>
                    </div>
                  </div>
                  {/* Admin delete button */}
                  {adminMode && (
                    <button
                      onClick={() => handleDelete(comment.id)}
                      className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-lg bg-red-900/50 text-red-400 hover:bg-red-700 hover:text-white transition-all duration-200 opacity-0 group-hover:opacity-100"
                      title="Eliminar comentario"
                    >
                      🗑️
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
